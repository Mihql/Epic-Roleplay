# Installation

To install the whole of YSI, use:

```
sampctl package install pawn-lang/YSI-Includes:5.x
```

To install just one library, see the documentation for [that library](readme.md)

To install the library without sampctl, you need to download an up-to-date release package from github, along with all the dependencies.  Have fun.  Otherwise, [just get sampctl](sampctl.com/)!

