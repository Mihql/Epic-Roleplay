# Internal Details.

This include isn't actually implemented in any one file, it is a collection of several functions all defined throughout YSI.  They should be together, but aren't, mainly due to when and why they were originally written.

